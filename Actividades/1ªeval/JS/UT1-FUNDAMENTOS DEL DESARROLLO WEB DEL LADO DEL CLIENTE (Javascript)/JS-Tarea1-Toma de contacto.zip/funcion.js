function funcion() {
   document.getElementById("prueba").innerHTML = " Cambiado";
}